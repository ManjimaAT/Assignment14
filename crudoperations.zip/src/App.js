import CrudApi from "./Crud";

function App() {
  return (
    <div className="App">
      <CrudApi/>
    </div>
  );
}

export default App;
