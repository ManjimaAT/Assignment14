import React, { useState, useEffect } from 'react';
import axios from 'axios';
import "./Crud.css";

const CrudApi = () => {
  const [users, setUsers] = useState([]);
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [selectedUserId, setSelectedUserId] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('https://jsonplaceholder.typicode.com/users');
        setUsers(response.data);
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    };

    fetchData();
  }, []);

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      if (selectedUserId) {
        const response = await axios.put(`https://jsonplaceholder.typicode.com/users/${selectedUserId}`, {
          name: newUserName,
          email: newUserEmail,
        });
        const updatedUser = response.data;
        setUsers(users.map(user => user.id === selectedUserId ? updatedUser : user));
        setSelectedUserId(null);
      } else {
        const response = await axios.post('https://jsonplaceholder.typicode.com/users', {
          name: newUserName,
          email: newUserEmail,
        });
        setUsers([...users, response.data]);
      }
      setNewUserName('');
      setNewUserEmail('');
    } catch (error) {
      console.error('Error creating/updating user:', error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`https://jsonplaceholder.typicode.com/users/${id}`);
      alert("Successfully deleted the user");
      setUsers(users.filter(user => user.id !== id));
    } 
    catch (error) {
      console.error('Error deleting user:', error);
    }
  };

  const handleEdit = (id, name, email) => {
    setSelectedUserId(id);
    setNewUserName(name);
    setNewUserEmail(email);
  };

  return (
    <div className='crud'>
      <h1>Users</h1>
      <ul>
        {users.map((user) => (
          <li key={user.id}>
            <div className="buttons-container">
              <span>{user.name} - {user.email}</span>
              <div className="buttons-right">
                <button className="edit" onClick={() => handleEdit(user.id, user.name, user.email)}>Edit</button>
                <button className="delete" onClick={() => handleDelete(user.id)}>Delete</button>
              </div>
            </div>
          </li>
        ))}
      </ul>
      <h2>{selectedUserId ? 'Edit User' : 'Create New User'}</h2>
      <form onSubmit={handleFormSubmit}>
        <input
          type="text"
          placeholder="Name"
          value={newUserName}
          onChange={(e) => setNewUserName(e.target.value)}
        />
        <input
          type="email"
          placeholder="Email"
          value={newUserEmail}
          onChange={(e) => setNewUserEmail(e.target.value)}
        />
        <button type="submit">{selectedUserId ? 'Update' : 'Submit'}</button>
        {selectedUserId && <button type="button" onClick={() => setSelectedUserId(null)}>Cancel</button>}
      </form>
    </div>
  );
};

export default CrudApi;
